import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = 'stress_rate'
FEATURE_KEYS = [
    'snoring_rate', 'respiration_rate', 'body_temp', 'limb_movement',
    'blood_oxygen', 'eye_movement', 'sleep_hours', 'heart_rate'
]

def transformed_name(key):
    '''Renaming transformed features'''
    return key + '_xf'

def preprocessing_fn(inputs):
    '''Preprocess input features for TensorFlow Transform'''

    table_keys = ['high/unhealthy', 'low/normal', 'medium', 'medium_high', 'medium_low']
    initializer = tf.lookup.KeyValueTensorInitializer(
        keys=table_keys,
        values=tf.cast(tf.range(len(table_keys)), tf.int64),
        key_dtype=tf.string,
        value_dtype=tf.int64
    )
    table = tf.lookup.StaticHashTable(initializer, default_value=-1)

    stress_rate = inputs[LABEL_KEY]
    stress_rate_encoded = table.lookup(stress_rate)

    # normalization
    outputs = {}
    for key in FEATURE_KEYS:
        outputs[transformed_name(key)] = tft.scale_to_z_score(inputs[key])
    
    # Add the encoded label to the outputs
    outputs[transformed_name(LABEL_KEY)] = stress_rate_encoded
    
    return outputs
    
# print mapping
table_keys = ['high/unhealthy', 'low/normal', 'medium', 'medium_high', 'medium_low']
for index, key in enumerate(table_keys):
    print(f"'{key}' is encoded as {index}")